import { getAuthToken } from 'src/app/core/auth-token.util';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable, shareReplay, tap } from 'rxjs';
export interface ProductListResponse {
  message: string;
  products: any[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}
@Injectable({
  providedIn: 'root',
})
export class ProductsService {
  private readonly baseUrl = `${environment.apiUrl}/product`;
  private readonly listCache = new Map<string, Observable<ProductListResponse>>();
  private readonly detailCache = new Map<string, Observable<any>>();

  constructor(private http: HttpClient) { }

  addProduct(
    formdata: FormData,
    categoryId: string
  ): any {
    return this.http.post(
      `${this.baseUrl}/addProduct/${categoryId}`,
      formdata,
      {
        headers: {
          authorization: `Bearer__${getAuthToken()}`,
        },
      }
    );
  }



  removeProduct(productId: string): any {
    return this.http.delete(
      `${this.baseUrl}/removeProduct/${encodeURIComponent(productId)}`,
      { headers: { authorization: `Bearer__${getAuthToken()}` } },
    ).pipe(tap(() => this.invalidateCache()));
  }
  getProduct(
  page = 1,
  limit = 12,
  search = ''
) {
  const params: Record<string, string> = {
    page: String(page),
    limit: String(limit),
  };

  const query = search.trim();

  if (query) {
    params['q'] = query;
  }

  const key = `${page}|${limit}|${query.toLowerCase()}`;
  const cached = this.listCache.get(key);
  if (cached) {
    return cached;
  }

  const request$ = this.http.get<ProductListResponse>(
    `${this.baseUrl}/allProducts`,
    { params }
  ).pipe(shareReplay({ bufferSize: 1, refCount: false }));

  this.listCache.set(key, request$);
  return request$;
}


  getSpecialOffers() {
    const key = 'special';
    const cached = this.listCache.get(key) as Observable<ProductListResponse> | undefined;
    if (cached) return cached;

    const request$ = this.http.get<any>(`${this.baseUrl}/getSpecialProduct`)
      .pipe(shareReplay({ bufferSize: 1, refCount: false }));
    this.listCache.set(key, request$ as Observable<ProductListResponse>);
    return request$;
  }

  getProductById(id: string) {
    const cached = this.detailCache.get(id);
    if (cached) return cached;

    const request$ = this.http.get<any>(`${this.baseUrl}/getProduct/${id}`)
      .pipe(shareReplay({ bufferSize: 1, refCount: false }));
    this.detailCache.set(id, request$);
    return request$;
  }

  invalidateCache(): void {
    this.listCache.clear();
    this.detailCache.clear();
  }

  deleteProduct(id: any) {
    return this.http.delete(`${this.baseUrl}/removeProduct/${id}`).pipe(tap(() => this.invalidateCache()));
  }
  getStoresProducts(id: any) {
    return this.http.get(`${this.baseUrl}/getStoresProducts/${id}`);
  }

    updateProduct(
    productId: string,
    formData: FormData
  ): Observable<any> {
    return this.http.put(
      `${this.baseUrl}/updateProduct/${productId}`,
      formData,
      {
        headers: {
          authorization: `Bearer__${getAuthToken()}`,
        },
      }
    ).pipe(tap(() => this.invalidateCache()));
  }
  /** @deprecated Use addProduct */
  addproduct(formdata: FormData, categoryId: string): any {
    return this.addProduct(formdata, categoryId);
  }

  /** @deprecated Use removeProduct */
  removeproduct(productId: string): any {
    return this.removeProduct(productId);
  }

}
