import { getAuthToken } from 'src/app/core/auth-token.util';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly baseUrl = `${environment.apiUrl}/cart`;
  private readonly cartSubject = new BehaviorSubject<any>(null);
  readonly cart$ = this.cartSubject.asObservable();

  constructor(private readonly http: HttpClient) {}

  loadCart(_token?: string): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/me`).pipe(
      tap(response => this.cartSubject.next(response?.cart ?? { products: [] }))
    );
  }

  addToCart(product: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/createCart`, product).pipe(
      tap(response => this.cartSubject.next(response?.cart ?? { products: [] }))
    );
  }

  removeFromCart(productId: string): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/deleteFromCart`, { productId }).pipe(
      tap(response => this.cartSubject.next(response?.cart ?? { products: [] }))
    );
  }

  updateQuantity(_token: string, product: { productId: string; quantity: number }): Observable<any> {
    return this.http.patch<any>(`${this.baseUrl}/changeQuantity`, product).pipe(
      tap(response => this.cartSubject.next(response?.cart ?? { products: [] }))
    );
  }

  clearCart(): void {
    this.cartSubject.next({ products: [] });
  }
}
