import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, tap, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Cart } from '../models/cart.model';
import { Product } from '../models/product.model';

@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly baseUrl = `${environment.apiUrl}/cart`;
  private readonly cartSubject = new BehaviorSubject<Cart | null>(null);
  readonly cart$ = this.cartSubject.asObservable();

  constructor(private readonly http: HttpClient) {}

  getMyCart(): Observable<{ cart: Cart }> {
    return this.http.get<{ cart: Cart }>(`${this.baseUrl}/me`).pipe(
      tap(response => this.cartSubject.next(response.cart ?? { products: [] })),
    );
  }

  addToCart(
    payload: { productId: string; quantity: number },
    previewProduct?: Product,
  ): Observable<{ cart: Cart }> {
    const previous = this.cartSubject.value;

    // Optimistic update: the header/cart count reacts before the network round-trip finishes.
    if (previewProduct?._id) {
      const current: Cart = previous ?? { products: [] };
      const existingIndex = current.products.findIndex(
        item => item.productId?._id === previewProduct._id,
      );
      const nextProducts = [...current.products];

      if (existingIndex >= 0) {
        nextProducts[existingIndex] = {
          ...nextProducts[existingIndex],
          quantity: nextProducts[existingIndex].quantity + payload.quantity,
        };
      } else {
        nextProducts.push({ productId: previewProduct, quantity: payload.quantity });
      }

      this.cartSubject.next({ ...current, products: nextProducts });
    }

    return this.http.post<{ cart: Cart }>(`${this.baseUrl}/createCart`, payload).pipe(
      tap(response => this.cartSubject.next(response.cart ?? { products: [] })),
      catchError(error => {
        this.cartSubject.next(previous);
        return throwError(() => error);
      }),
    );
  }

  removeFromCart(productId: string): Observable<{ cart: Cart }> {
    const previous = this.cartSubject.value;
    if (previous) {
      this.cartSubject.next({
        ...previous,
        products: previous.products.filter(item => item.productId?._id !== productId),
      });
    }

    return this.http.put<{ cart: Cart }>(`${this.baseUrl}/deleteFromCart`, { productId }).pipe(
      tap(response => this.cartSubject.next(response.cart ?? { products: [] })),
      catchError(error => {
        this.cartSubject.next(previous);
        return throwError(() => error);
      }),
    );
  }

  updateQuantity(productId: string, quantity: number): Observable<{ cart: Cart }> {
    const previous = this.cartSubject.value;
    if (previous) {
      this.cartSubject.next({
        ...previous,
        products: previous.products
          .map(item => item.productId?._id === productId ? { ...item, quantity } : item)
          .filter(item => item.quantity > 0),
      });
    }

    return this.http.patch<{ cart: Cart }>(`${this.baseUrl}/changeQuantity`, { productId, quantity }).pipe(
      tap(response => this.cartSubject.next(response.cart ?? { products: [] })),
      catchError(error => {
        this.cartSubject.next(previous);
        return throwError(() => error);
      }),
    );
  }

  setCart(cart: Cart | null | undefined): void {
    this.cartSubject.next(cart ?? { products: [] });
  }

  clear(): void {
    this.cartSubject.next({ products: [] });
  }
}
